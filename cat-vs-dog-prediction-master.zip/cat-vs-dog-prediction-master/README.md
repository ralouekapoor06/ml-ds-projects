The following is a cat vs dog prediction model.
The following model has not been made using any high level frameworks
The dataset was downloaded from kaggle
The code was made after taking reference from kaggle
